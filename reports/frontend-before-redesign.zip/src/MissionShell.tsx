import { lazy, Suspense, useEffect, useState } from 'react'
import App from './App'
import { DataCenter, MissionComparison, MissionHome, SurvivalCenter } from './MissionPages'
import type { Assessment, Coordinates } from './mars'
import type { Candidate } from './science'
import './mission.css'

const NavigationLab = lazy(() => import('./NavigationLab'))
const PAGES = [
  ['home', 'Mission home'], ['explore', 'Global explorer'], ['location', 'Location intelligence'],
  ['planner', 'Route planner'], ['survival', 'Survival center'], ['navigation', 'Navigation technology'],
  ['comparison', 'Mission comparison'], ['data', 'Data center'],
] as const
type Page = typeof PAGES[number][0]
const SAVED_KEY = 'martian-map-candidates-v1'

function pageFromHash(): Page {
  const hash = location.hash.slice(1)
  return PAGES.find(([key]) => key === hash)?.[0] ?? 'home'
}

function initialCandidates(): Candidate[] {
  try {
    const data: unknown = JSON.parse(localStorage.getItem(SAVED_KEY) ?? '[]')
    if (!Array.isArray(data)) return []
    return data.filter((site) => Number.isFinite(site?.point?.latitude) && Number.isFinite(site?.point?.longitude) &&
      Array.isArray(site?.assessment?.factors) && typeof site?.savedAt === 'string')
  } catch {
    return []
  }
}

export default function MissionShell() {
  const [page, setPage] = useState(pageFromHash)
  const [point, setPoint] = useState<Coordinates | null>(null)
  const [candidates, setCandidates] = useState(initialCandidates)
  const [storageError, setStorageError] = useState(false)
  const [notice, setNotice] = useState('')
  useEffect(() => {
    const navigate = () => { setPage(pageFromHash()); window.scrollTo(0, 0) }
    window.addEventListener('hashchange', navigate)
    return () => window.removeEventListener('hashchange', navigate)
  }, [])
  const selectSite = (site: Coordinates, openReport = true) => {
    setNotice('')
    setPoint(site)
    if (openReport) location.hash = 'location'
  }
  const store = (next: Candidate[]) => {
    setCandidates(next)
    try {
      localStorage.setItem(SAVED_KEY, JSON.stringify(next))
      setStorageError(false)
    } catch { setStorageError(true) }
  }
  const saveSite = (site: Coordinates, assessment: Assessment) => {
    const saved = candidates.filter(({ point }) => Math.abs(point.latitude - site.latitude) >= 0.00001 || Math.abs(point.longitude - site.longitude) >= 0.00001)
    store([{ point: site, assessment, savedAt: new Date().toISOString() }, ...saved])
    setNotice('Candidate saved. Open Mission comparison to rank or export it.')
  }
  const appPage = page === 'explore' || page === 'location' || page === 'planner' ? page : null

  return <>
    <header className="mission-header">
      <a className="mission-brand" href="#home"><span aria-hidden="true" />MARTIAN MAP</a>
      <nav aria-label="Mission workspaces">
        {PAGES.map(([key, label]) => <a href={`#${key}`} key={key} aria-current={page === key ? 'page' : undefined}>{label}</a>)}
      </nav>
    </header>
    {storageError && <p className="mission-notice" role="alert">Browser storage is unavailable. Candidate changes apply to this session.</p>}
    {notice && page === 'location' && <p className="mission-notice" role="status">{notice}</p>}
    <App page={appPage} point={point} selectSite={selectSite} saveSite={saveSite} />
    {page === 'home' && <main><MissionHome count={candidates.length} /></main>}
    {page === 'survival' && <main><SurvivalCenter point={point} /></main>}
    {page === 'data' && <main><DataCenter /></main>}
    {page === 'comparison' && <main><MissionComparison candidates={candidates} onSelect={selectSite} onRemove={(candidate) => store(candidates.filter((other) => other !== candidate))} /></main>}
    {page === 'navigation' && <main><Suspense fallback={<p role="status">Loading navigation lab…</p>}><NavigationLab /></Suspense></main>}
  </>
}
