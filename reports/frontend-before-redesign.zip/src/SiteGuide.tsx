import { useEffect, useRef, useState } from 'react'
import type { Assessment, Coordinates, SurfaceRoutes } from './mars'
import { coordinatesLabel, FACTOR_LABELS } from './mars'
import { fmtDist } from './render'
import { SCIENCE_DATA, siteTitle, survivalEvidence } from './science'

const QUESTIONS = ['Landing suitability', 'Geological risks', 'Water and settlement', 'Preferred surface route'] as const
type Topic = typeof QUESTIONS[number]
interface Citation { id: string; url: string }

export default function SiteGuide({ point, assessment, score, paths }: { point: Coordinates; assessment: Assessment; score: number | null; paths: SurfaceRoutes | null }) {
  const [topic, setTopic] = useState<Topic>('Landing suitability')
  const [question, setQuestion] = useState('')
  const [answer, setAnswer] = useState<{ answer: string; sources: Citation[] } | null>(null)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const pending = useRef<AbortController | null>(null)
  useEffect(() => () => pending.current?.abort(), [])
  const hazard = assessment.hazard
  const safest = paths?.routes.safest?.metrics
  const factors = assessment.factors.filter((factor) => factor.score !== null).sort((a, b) => (a.score ?? 0) - (b.score ?? 0))
  const weakest = factors[0]
  const water = survivalEvidence(point)[0]
  const responses: Record<Topic, { text: string; source: { name: string; url: string } }> = {
    'Landing suitability': {
      text: assessment.level === 'local'
        ? `The preliminary terrain score is ${score ?? 'unavailable'}${score === null ? '' : '/100'}. ${weakest ? `The lowest measured factor is ${FACTOR_LABELS[weakest.key].toLowerCase()} (${weakest.score}/100). ` : ''}Rock abundance and soil stability remain unverified.`
        : 'Regional MOLA cells are too coarse for a landing decision. A local terrain model and obstacle survey are required.',
      source: SCIENCE_DATA[assessment.level === 'local' ? 3 : 2],
    },
    'Geological risks': {
      text: hazard ? `The nearest catalogued large crater rim is about ${hazard.rimDistanceKm} km away. This is a circular rim estimate based on a mapped diameter. Boulder, rock-field and dune coverage remains unverified.`
        : 'The crater catalog did not return a distance. Boulder, rock-field and dune coverage remains unverified.',
      source: SCIENCE_DATA[5],
    },
    'Water and settlement': { text: water.detail + ' A settlement study also needs local power, shielding and communication models.', source: { name: 'Water evidence', url: water.url } },
    'Preferred surface route': {
      text: safest ? `The lower-exposure strategy covers ${fmtDist(safest.distance_m)} with a modeled risk index of ${safest.risk_score}/100. ${safest.energy_feasible ? 'It meets the selected energy reserve.' : 'It would breach the selected energy reserve.'}`
        : 'A route comparison requires a matching local elevation grid and reachable waypoint.',
      source: SCIENCE_DATA[3],
    },
  }

  function ask() {
    if (question.trim().length < 3) return
    pending.current?.abort()
    const controller = new AbortController()
    pending.current = controller
    setBusy(true)
    setAnswer(null)
    setError('')
    fetch('/api/guide', {
      method: 'POST', signal: controller.signal, headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...point, question: question.trim() }),
    }).then(async (response) => {
      const data = await response.json()
      if (!response.ok) throw new Error(typeof data.detail === 'string' ? data.detail : 'Scientific guide unavailable.')
      if (!controller.signal.aborted) setAnswer(data)
    }).catch((err) => { if (!controller.signal.aborted) setError(err.message) })
      .finally(() => { if (!controller.signal.aborted) setBusy(false) })
  }
  return <div className="site-guide">
    <h3>Scientific guide</h3>
    <p className="mars-muted">{siteTitle(point)} · {coordinatesLabel(point)}</p>
    <div className="mission-tabs" aria-label="Evidence topics">
      {QUESTIONS.map((label) => <button key={label} aria-pressed={topic === label} onClick={() => setTopic(label)}>{label}</button>)}
    </div>
    <p>{responses[topic].text}</p>
    <a href={responses[topic].source.url} target="_blank" rel="noreferrer">{responses[topic].source.name} ↗</a>
    <form className="guide-question" onSubmit={(e) => { e.preventDefault(); ask() }}>
      <label>Ask about this site <textarea value={question} onChange={(event) => setQuestion(event.target.value)} maxLength={480} required minLength={3} placeholder="What makes this area scientifically interesting?" /></label>
      <button disabled={busy}>{busy ? 'Preparing answer…' : 'Ask AI guide'}</button>
    </form>
    {error && <p role="status" className="mars-muted">{error}</p>}
    {answer && <div aria-live="polite"><h4>AI-generated explanation</h4><p>{answer.answer}</p>
      {answer.sources.map(({ id, url }) => <p key={id}><a href={url} target="_blank" rel="noreferrer">{id} ↗</a></p>)}</div>}
  </div>
}
