import type { Assessment, Coordinates } from './mars'
import { identifyRegion, LANDMARKS } from './mars'
import type { Metrics, RouteKey } from './types'

export const JEZERO_WEATHER = {
  pressure: '650–761 Pa',
  wind: 'Up to 25 m/s in recorded gusts',
  temperature: 'About 52°C peak-to-peak in the daily component',
  source: 'https://doi.org/10.1038/s41561-022-01084-0',
}

const REGION_NAMES: Record<string, string> = {
  Jezero: 'فُوَّهَة جِيزِيرُو',
  'Olympus Mons': 'جَبَل أُولِيمْبُوس',
  'Valles Marineris': 'وِدْيَان مَارِينِيرِس',
  Gale: 'فُوَّهَة غَيْل',
  'Hellas Planitia': 'سَهْل هِيلَاس',
}

const ROUTE_NAMES: Record<RouteKey, string> = { shortest: 'الأَقْصَر', safest: 'الأَقَلّ خُطُورَةً', optimal: 'المُتَوَازِن' }

export function isJezero(point: Coordinates) {
  return identifyRegion(point)?.name === LANDMARKS[0].name
}

export function terrainStatus(assessment: Assessment, score: number | null) {
  const slope = assessment.factors.find(({ key }) => key === 'slope')?.value
  const zone = assessment.factors.find(({ key }) => key === 'zone')?.value
  if (assessment.level !== 'local' || score === null || slope == null || zone == null) return 'unknown'
  return score < 60 || slope > 8 || zone < 100 ? 'elevated' : 'lower'
}

export function siteNarration(point: Coordinates, assessment: Assessment, score: number | null, route: Metrics | undefined, key: RouteKey, routeBusy: boolean) {
  const factor = (id: string) => assessment.factors.find(({ key: factorKey }) => factorKey === id)?.value
  const feature = identifyRegion(point)
  const number = (value: number, decimals = 1) => Math.abs(Number(value.toFixed(decimals))).toString()
  const elevation = factor('elevation')
  const slope = factor('slope')
  const roughness = factor('roughness')
  const zone = factor('zone')
  const hazard = assessment.hazard
  const status = terrainStatus(assessment, score)
  return [
    `تَقْرِير المَوْقِع عَلَى المِرِّيخ. ${feature ? REGION_NAMES[feature.name] : 'مَوْقِع عَلَى السَّطْح'}.`,
    `خَطّ العَرْض ${number(point.latitude, 3)} دَرَجَة ${point.latitude < 0 ? 'جَنُوبًا' : 'شَمَالًا'}، وَخَطّ الطُّول ${number(point.longitude, 3)} دَرَجَة ${point.longitude < 0 ? 'غَرْبًا' : 'شَرْقًا'}.`,
    elevation != null && `الاِرْتِفَاع ${number(elevation, 0)} مِتْر ${elevation < 0 ? 'تَحْتَ' : 'فَوْقَ'} المُسْتَوَى المَرْجِعِيّ.`,
    slope != null && `${assessment.level === 'regional' ? 'المَيْل الإِقْلِيمِيّ' : 'مَيْل السَّطْح'} ${number(slope)} دَرَجَة.`,
    roughness != null && `خُشُونَة التَّضَارِيس ${number(roughness)} مِتْر.`,
    zone != null && `القُطْر التَّقْرِيبِيّ لِلْمِنْطَقَة المُنْبَسِطَة ${number(zone, 0)} مِتْر.`,
    hazard && `أَقْرَب حَافَّة فُوَّهَة كَبِيرَة تَبْعُد ${number(hazard.rimDistanceKm)} كِيلُومِتْر.`,
    status === 'unknown' ? 'بَيَانَات المَوْقِع لا تَكْفِي لِتَحْدِيدِ السَّلَامَة.' : `مَخَاطِر التَّضَارِيس ${status === 'elevated' ? 'مُرْتَفِعَة' : 'مُنْخَفِضَة نِسْبِيًّا'}. النَّتِيجَة التَّعْلِيمِيَّة ${score} مِنْ مِئَة.`,
    'قِيَاسَات الصُّخُور وَحَالَة الطَّقْس الحَالِيَّة غَيْر مُتَوَفِّرَة.',
    isJezero(point) && 'سَجَّلَت بِيْرْسِفِيرَانْس ضَغْطًا يَوْمِيًّا بَيْنَ 650 وَ761 بَاسْكَال فِي أَوَائِل المَهَمَّة، وَهَبَّات رِيَاح وَصَلَت إِلَى 25 مِتْرًا فِي الثَّانِيَة. وَبَلَغَ تَغَيُّرُ حَرَارَةِ الهَوَاءِ اليَوْمِيُّ نَحْوَ 52 دَرَجَة مِئَوِيَّة.',
    route
      ? `المَسَار ${ROUTE_NAMES[key]}. طُولُهُ ${number(route.distance_m, 0)} مِتْرًا، وَمُؤَشِّر الخُطُورَة ${number(route.risk_score, 0)} مِنْ مِئَة. ${route.energy_feasible ? 'الطَّاقَة المُقَدَّرَة تَكْفِي لِلْعُبُور.' : 'الطَّاقَة المُقَدَّرَة لا تَكْفِي لِلْعُبُور مَعَ الاِحْتِيَاطِيّ.'}`
      : routeBusy ? 'جَارٍ حِسَاب المَسَار.' : 'مَسَار سَطْحِيّ غَيْر مُتَاح لِهَذَا المَوْقِع.',
  ].filter(Boolean).join(' ')
}
