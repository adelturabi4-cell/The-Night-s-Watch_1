import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './styles.css'
import MissionShell from './MissionShell'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <MissionShell />
  </StrictMode>,
)
