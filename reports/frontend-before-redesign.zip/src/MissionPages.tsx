import { useEffect, useRef, useState } from 'react'
import { coordinatesLabel, DEFAULT_LANDING_WEIGHTS, scoreAssessment } from './mars'
import type { Coordinates } from './mars'
import { SCIENCE_DATA, siteTitle, survivalEvidence } from './science'
import type { Candidate } from './science'

export function MissionHome({ count }: { count: number }) {
  return <>
    <section className="mission-hero">
      <figure><img src="/mars/mars-viking-globe.jpg" alt="Viking orbital mosaic of the Valles Marineris hemisphere" /><figcaption>Viking Orbiter · NASA/JPL-Caltech</figcaption></figure>
      <div className="hero-copy">
        <p className="page-kicker">Mars exploration &amp; mission planning</p>
        <h1>Read the terrain.<br />Plan the mission.</h1>
        <p>Explore real orbital maps, assess landing sites, and compare surface routes across the Martian landscape.</p>
        <div className="mission-actions"><a className="mission-primary" href="#explore">Explore Mars <span aria-hidden="true">↗</span></a><a href="#comparison">Saved sites ({count})</a></div>
      </div>
    </section>
    <section className="mission-content">
      <h2>Mission workspaces</h2>
      <div className="mission-cards">
        <a href="#location"><h3>Location intelligence</h3><p>Review terrain, site hazards and the evidence behind landing suitability.</p></a>
        <a href="#planner"><h3>Route planner</h3><p>Compare three A* routes with adjustable mobility and mission priorities.</p></a>
        <a href="#survival"><h3>Survival center</h3><p>Review water, radiation, power, atmosphere and communications evidence.</p></a>
      </div>
      <h2>Mission findings</h2>
      <div className="mission-cards">
        <a href="https://science.nasa.gov/photojournal/mars-global-localization-pinpoints-perseverances-location/" target="_blank" rel="noreferrer"><h3>Perseverance localizes from orbit maps</h3><p>NASA Science · Mars Global Localization · February 2026</p></a>
        <a href="https://science.nasa.gov/blog/linking-local-lithologies-to-a-larger-landscape/" target="_blank" rel="noreferrer"><h3>Rocks on Jezero’s rim</h3><p>NASA Science · Orbital and rover geology</p></a>
      </div>
    </section>
  </>
}

export function SurvivalCenter({ point }: { point: Coordinates | null }) {
  return <section className="mission-content">
    <h1>Mission survival center</h1>
    <p className="page-description">{point ? `${siteTitle(point)} · ${coordinatesLabel(point)}` : 'Planetary reference. Select a site to see applicable regional evidence.'}</p>
    <SurvivalEvidence point={point} />
  </section>
}

export function SurvivalEvidence({ point }: { point: Coordinates | null }) {
  return <div className="mission-cards">{survivalEvidence(point).map(({ topic, status, detail, url }) =>
    <article key={topic}><h3>{topic}</h3><p className="evidence-label">{status}</p><p>{detail}</p><a href={url} target="_blank" rel="noreferrer">Scientific source ↗</a></article>
  )}</div>
}

export function DataCenter() {
  return <section className="mission-content">
    <h1>Scientific data center</h1>
    <p className="page-description">Instrument products, derived layers and coverage used by the workspaces.</p>
    <div className="mission-cards">{SCIENCE_DATA.map(({ name, type, scope, revision, method, url }) =>
      <article key={name}><p className="evidence-label">{type}</p><h3>{name}</h3><p>{scope} · {revision}</p><p>{method}</p><a href={url} target="_blank" rel="noreferrer">Dataset ↗</a></article>
    )}</div>
  </section>
}

export function MissionComparison({ candidates, onRemove, onSelect }: {
  candidates: Candidate[]
  onRemove: (candidate: Candidate) => void
  onSelect: (point: Coordinates) => void
}) {
  const [ordering, setOrdering] = useState('landing')
  const [advice, setAdvice] = useState<{ answer: string; sources: { id: string; url: string }[] } | null>(null)
  const [adviceError, setAdviceError] = useState('')
  const [adviceBusy, setAdviceBusy] = useState(false)
  const adviceRequest = useRef<AbortController | null>(null)
  useEffect(() => {
    return () => adviceRequest.current?.abort()
  }, [])
  const ranked = candidates.map((candidate) => ({
    ...candidate, score: scoreAssessment(candidate.assessment.factors, DEFAULT_LANDING_WEIGHTS),
  }))
  if (ordering === 'landing') ranked.sort((a, b) => (b.assessment.level === 'local' ? b.score ?? -1 : -1) - (a.assessment.level === 'local' ? a.score ?? -1 : -1))
  else ranked.sort((a, b) => b.savedAt.localeCompare(a.savedAt))
  const top = ranked.find((c) => c.assessment.level === 'local' && c.score !== null)
  const value = (candidate: Candidate, key: string) => {
    const factor = candidate.assessment.factors.find((f) => f.key === key)
    return factor?.value == null ? 'Unavailable' : `${factor.value} ${factor.unit}`
  }
  const exportReport = () => {
    const report = {
      basis: 'Educational comparison. Only local-resolution assessments receive a landing rank. Scores use standard weights.',
      weights: DEFAULT_LANDING_WEIGHTS,
      candidates: ranked.map((c) => ({ ...c, site: siteTitle(c.point), survival: survivalEvidence(c.point) })),
      sources: SCIENCE_DATA,
    }
    const url = URL.createObjectURL(new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' }))
    const link = document.createElement('a')
    link.href = url
    link.download = 'martian-map-mission-report.json'
    link.click()
    window.setTimeout(() => URL.revokeObjectURL(url), 1000)
  }
  const askMissionAdvisor = async () => {
    adviceRequest.current?.abort()
    const controller = new AbortController()
    adviceRequest.current = controller
    setAdviceBusy(true)
    setAdvice(null)
    setAdviceError('')
    try {
      const response = await fetch('/api/guide/mission', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ candidates: candidates.map(({ point }) => point) }),
        signal: controller.signal,
      })
      const data = await response.json()
      if (!response.ok) throw new Error(typeof data.detail === 'string' ? data.detail : 'Mission advisor unavailable.')
      if (!controller.signal.aborted) setAdvice(data)
    } catch (error) {
      if (!controller.signal.aborted) setAdviceError(error instanceof Error ? error.message : 'Mission advisor unavailable.')
    } finally {
      if (!controller.signal.aborted) setAdviceBusy(false)
    }
  }
  const removeCandidate = (candidate: Candidate) => {
    adviceRequest.current?.abort()
    setAdvice(null)
    setAdviceError('')
    setAdviceBusy(false)
    onRemove(candidate)
  }
  return <section className="mission-content">
    <h1>Mission comparison</h1>
    {ranked.length === 0 ? <p className="page-description">Select a point in the <a href="#explore">Global Explorer</a> and save it as a candidate.</p> : <>
      <div className="mission-toolbar">
        <label>Rank by <select value={ordering} onChange={(e) => setOrdering(e.target.value)}><option value="landing">Local landing score</option><option value="recent">Recently saved</option></select></label>
        <button className="primary" onClick={exportReport}>Export report</button>
        <button onClick={askMissionAdvisor} disabled={adviceBusy || candidates.length < 2 || candidates.length > 8}>
          {adviceBusy ? 'Analyzing candidates…' : 'Ask AI mission advisor'}
        </button>
      </div>
      <p className="page-description">The AI compares up to 8 saved sites using available terrain safety and science-evidence coverage. Scientific evidence coverage is a proxy, not a measure of discovery potential.</p>
      {candidates.length === 1 && <p className="mission-notice" role="status">Save at least one more site to compare candidates with the AI advisor.</p>}
      {candidates.length > 8 && <p className="mission-notice" role="status">The AI advisor supports up to 8 sites per comparison. Remove candidates to continue.</p>}
      {adviceError && <p className="mission-notice" role="alert">{adviceError}</p>}
      {advice && <section className="mission-advice" aria-live="polite">
        <h2>AI mission recommendation</h2>
        <p className="page-description">Candidate numbers in the answer follow this list:</p>
        <ol>{candidates.map((candidate, index) => <li key={`${index}-${coordinatesLabel(candidate.point)}`}>{index + 1}. {siteTitle(candidate.point)} · {coordinatesLabel(candidate.point)}</li>)}</ol>
        <p>{advice.answer}</p>
        {advice.sources.map(({ id, url }) => <a key={id} href={url} target="_blank" rel="noreferrer">{id} ↗</a>)}
      </section>}
      <p className="page-description">{top ? `${siteTitle(top.point)} has the highest available local terrain score (${top.score}/100). Verify environmental and site data before prioritizing it.` : 'Local coverage is required for a landing ranking.'}</p>
      <div className="comparison-scroll"><table className="mission-table">
        <thead><tr>{['Site', 'Landing score', 'Slope', 'Roughness', 'Access', 'Water evidence', 'Energy', 'Communications', 'Scientific context', ''].map((label) => <th key={label}>{label}</th>)}</tr></thead>
        <tbody>{ranked.map((c) => <tr key={coordinatesLabel(c.point)}>
          <th><button onClick={() => onSelect(c.point)}>{siteTitle(c.point)}</button><br />{coordinatesLabel(c.point)}</th>
          <td>{c.assessment.level === 'local' && c.score !== null ? `${c.score}/100` : 'Regional only'}</td>
          <td>{value(c, 'slope')}</td><td>{value(c, 'roughness')}</td><td>{value(c, 'access')}</td>
          <td>{siteTitle(c.point) === 'Jezero crater' ? 'Ancient water evidence' : 'Unverified'}</td><td>Yield unavailable</td><td>Geometry unavailable</td>
          <td>{siteTitle(c.point)}</td><td><button onClick={() => removeCandidate(c)}>Remove</button></td>
        </tr>)}</tbody>
      </table></div>
    </>}
  </section>
}
