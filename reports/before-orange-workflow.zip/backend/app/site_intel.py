"""Site intelligence: what is at a selected Mars location, and can you go there?

``site_report`` gathers evidence from every ingested dataset. ``decide`` turns
that evidence into one verdict with explicit reasons. The rules are kept in a
pure function so they can be tested without rasters:

* ``go``       - local 20 m terrain exists and the cell is inside the mobility limits.
* ``caution``  - local terrain exists and at least one warning applies.
* ``no_go``    - a blocking rule applies (slope beyond the vehicle limit).
* ``unknown``  - no local terrain: unknown ground is never reported as safe.

This is an educational planning model, not an operational safety approval.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from functools import lru_cache

import numpy as np

from . import jezero as pack
from .data_catalog import pack_topography, region_at
from .landing import CRATER_SOURCE, CTX_SOURCE, MOLA_SOURCE, crater_context, global_topography, local_grid
from .landing import jezero as jezero_terrain
from .planner import CLASS_NAMES, analyse
from .profiles import Profile

ROUGH_WARN_M = 1.2        # same threshold as the terrain cell inspector
NEIGHBOUR_RADIUS_M = 100  # ring used for the "surrounded by steep ground" check
RIM_WARN_KM = 0.5
SAND_UNITS = {"Aeb"}      # eolian bedforms: possible loose sand (interpretive map)
PROFILE_AR = {"astronaut_eva": "رائد فضاء مشيًا", "rover_scout": "عربة استطلاع خفيفة", "rover_large": "عربة علمية كبيرة"}

LABELS = {
    "go": ("يمكن الذهاب", "Reachable within the model limits"),
    "caution": ("يمكن الذهاب بحذر", "Reachable with caution"),
    "no_go": ("لا يمكن الذهاب", "Not traversable for this profile"),
    "unknown": ("غير مؤكد — البيانات لا تكفي", "Unconfirmed — insufficient data"),
}
UNAVAILABLE = [
    {"key": "rocks", "label": "وفرة الصخور والعوائق الصغيرة", "why": "لا توجد طبقة معايرة لوفرة الصخور."},
    {"key": "soil", "label": "تماسك التربة", "why": "لا توجد قياسات ميكانيكا تربة للموقع."},
    {"key": "weather", "label": "الطقس الحالي", "why": "لا يوجد بث طقس مباشر مرتبط بالنظام."},
    {"key": "radiation", "label": "جرعة الإشعاع في الموقع", "why": "لا يوجد نموذج إشعاع خاص بالموقع."},
]


@dataclass(frozen=True)
class Reason:
    code: str
    severity: str  # "block" | "warn" | "ok" | "info"
    text: str
    value: float | None = None
    limit: float | None = None
    unit: str | None = None
    source: str | None = None


@dataclass(frozen=True)
class Evidence:
    """Everything the decision rules may use. ``None`` means not measured."""
    level: str  # "local" (CTX 20 m) | "regional" (MOLA)
    slope_deg: float | None = None
    roughness_m: float | None = None
    terrain_class: str | None = None
    blocked_share: float | None = None
    rim_distance_km: float | None = None
    unit_symbol: str | None = None
    unit_name: str | None = None
    surface_feature: str | None = None
    small_craters: int | None = None


def decide(evidence: Evidence, profile: Profile) -> dict:
    """Apply the access rules. Returns status, labels and ordered reasons."""
    e, limit, reasons = evidence, profile.max_slope_deg, []
    who = PROFILE_AR.get(profile.id, profile.label)
    local = e.level == "local"
    slope_source = CTX_SOURCE if local else MOLA_SOURCE
    scale = "خلية 20 م" if local else "متوسط إقليمي على عدة كيلومترات"

    if local and e.terrain_class == "unknown":
        reasons.append(Reason("no_elevation", "info", "بيانات الارتفاع في هذه الخلية ناقصة أو غير موثوقة.", source=CTX_SOURCE))
    elif e.slope_deg is None:
        reasons.append(Reason("slope_unavailable", "info", "لا يمكن حساب الميل عند هذه النقطة من البيانات المتوفرة."))
    elif e.slope_deg > limit:
        reasons.append(Reason("slope_exceeds_limit", "block",
                              f"الميل {e.slope_deg:.1f}° ({scale}) يتجاوز حد الحركة {limit:.0f}° لـ«{who}».",
                              e.slope_deg, limit, "°", slope_source))
    elif local:
        reasons.append(Reason("slope_within_limit", "ok",
                              f"الميل {e.slope_deg:.1f}° ضمن حد الحركة {limit:.0f}° لـ«{who}».",
                              e.slope_deg, limit, "°", slope_source))
    else:
        reasons.append(Reason("regional_slope_only", "info",
                              f"الميل الإقليمي {e.slope_deg:.1f}° لا يُظهر مانعًا، لكنه متوسط على كيلومترات ولا يكشف المنحدرات والصخور المحلية.",
                              e.slope_deg, limit, "°", slope_source))

    if not local:
        reasons.append(Reason("no_local_terrain", "info",
                              "لا توجد تضاريس محلية عالية الدقة هنا؛ التغطية الدقيقة متوفرة حاليًا في فوهة Jezero فقط."))
    else:
        if e.terrain_class == "high_risk":
            reasons.append(Reason("high_modelled_risk", "warn", "خطر الحركة المحسوب مرتفع (ميل قريب من الحد مع خشونة).", source=CTX_SOURCE))
        elif e.terrain_class == "moderate":
            reasons.append(Reason("moderate_modelled_risk", "warn", "خطر الحركة المحسوب متوسط.", source=CTX_SOURCE))
        if e.roughness_m is not None and e.roughness_m > ROUGH_WARN_M:
            reasons.append(Reason("rough_surface", "warn", f"خشونة السطح مرتفعة ({e.roughness_m:.2f} م RMS) وتزيد صعوبة الحركة.",
                                  e.roughness_m, ROUGH_WARN_M, "m RMS", CTX_SOURCE))
        if e.blocked_share is not None and e.blocked_share >= 0.5:
            reasons.append(Reason("surrounded_by_blocked", "warn",
                                  f"{e.blocked_share * 100:.0f}% من الخلايا ضمن {NEIGHBOUR_RADIUS_M} م غير قابلة للعبور؛ قد يتعذّر الوصول فعليًا.",
                                  e.blocked_share * 100, 50, "%", CTX_SOURCE))
    if e.rim_distance_km is not None and e.rim_distance_km < RIM_WARN_KM:
        reasons.append(Reason("near_crater_rim", "warn" if local else "info",
                              f"النقطة على بعد {e.rim_distance_km:.2f} كم من حافة فوهة كبيرة (حافة مقرَّبة بدائرة).",
                              e.rim_distance_km, RIM_WARN_KM, "km", CRATER_SOURCE))
    if e.unit_symbol in SAND_UNITS:
        reasons.append(Reason("loose_bedforms", "warn" if local else "info",
                              f"الوحدة الجيولوجية «{e.unit_name}» تموّجات رملية ريحية قد تُضعف التماسك (خريطة تفسيرية، ليست قياس تربة).",
                              source="USGS SIM 3464"))
    if e.surface_feature:
        reasons.append(Reason("mapped_surface_feature", "info", f"معلَم سطحي مرسوم في خريطة USGS: {e.surface_feature}.", source="USGS SIM 3464"))
    if e.small_craters:
        reasons.append(Reason("small_craters_nearby", "info", f"{e.small_craters} فوهة صغيرة (200–500 م) مرسومة ضمن 300 م.",
                              e.small_craters, source="USGS SIM 3464"))

    severities = {reason.severity for reason in reasons}
    if "block" in severities:
        status = "no_go"
    elif not local or e.terrain_class == "unknown" or e.slope_deg is None:
        status = "unknown"
    else:
        status = "caution" if "warn" in severities else "go"
    order = {"block": 0, "warn": 1, "ok": 2, "info": 3}
    reasons.sort(key=lambda reason: order[reason.severity])
    return {
        "status": status, "label": LABELS[status][0], "labelEn": LABELS[status][1],
        "confidence": "local" if local else "regional",
        "reasons": [asdict(reason) for reason in reasons],
        "nextStep": ("احسب مسارًا من نقطة الانطلاق للتحقق من الاتصال والطاقة." if status in ("go", "caution")
                     else "اختر نقطة أخرى أو غيّر وسيلة الحركة." if status == "no_go"
                     else "يلزم نموذج ارتفاعات عالي الدقة لهذه المنطقة قبل الحكم."),
        "limits": "تقدير تعليمي مشتق من بيانات مدارية. ليس ضمان أمان؛ الصخور والتربة والطقس غير مقاسة.",
    }


@lru_cache(maxsize=16)
def _analysis(profile: Profile) -> dict:
    return analyse(jezero_terrain()[0], profile)


def _local_evidence(sample, profile: Profile) -> dict:
    terrain, _, _, row, col = sample
    analysis = _analysis(profile)
    radius = max(1, int(NEIGHBOUR_RADIUS_M / terrain.cell_size))
    window = analysis["cls"][max(0, row - radius):row + radius + 1, max(0, col - radius):col + radius + 1]
    slope, roughness = float(terrain.slope_deg[row, col]), float(terrain.roughness[row, col])
    return {
        "elevation": float(terrain.elevation[row, col]),
        "slope": slope if np.isfinite(slope) else None,
        "roughness": roughness if np.isfinite(roughness) else None,
        "class": CLASS_NAMES[int(analysis["cls"][row, col])],
        "risk": round(float(analysis["risk"][row, col]), 3) if np.isfinite(analysis["risk"][row, col]) else None,
        "blocked_share": float(np.mean(window >= 3)),
    }


def site_report(lat: float, lon: float, profile: Profile) -> dict:
    """Full evidence and verdict for one selected coordinate."""
    sample = local_grid(lat, lon)
    _, hazard = crater_context(lat, lon)
    unit = pack.geologic_unit_at(lat, lon)
    feature = pack.surface_feature_at(lat, lon)
    craters = pack.small_craters_near(lat, lon)
    rim = hazard["rimDistanceKm"] if hazard else None

    if sample:
        local = _local_evidence(sample, profile)
        terrain = {"level": "local", "resolutionM": sample[0].cell_size, "source": CTX_SOURCE,
                   "elevationM": round(local["elevation"], 1), "slopeDeg": local["slope"],
                   "roughnessM": local["roughness"], "class": local["class"], "risk": local["risk"]}
        evidence = Evidence("local", local["slope"], local["roughness"], local["class"], local["blocked_share"], rim,
                            unit and unit["symbol"], unit and unit["name"], feature, craters and craters["count"])
    else:
        elevation, slope = global_topography(lat, lon)
        packed = pack_topography(lat, lon) is not None
        terrain = {"level": "regional", "resolutionM": 3705 if packed else 14820,
                   "source": "MOLA MEGT90N000EB · 3,705 m/pixel" if packed else MOLA_SOURCE,
                   "elevationM": round(elevation, 1) if elevation is not None else None,
                   "slopeDeg": round(slope, 2) if slope is not None else None,
                   "roughnessM": None, "class": None, "risk": None}
        evidence = Evidence("regional", slope, rim_distance_km=rim, unit_symbol=unit and unit["symbol"],
                            unit_name=unit and unit["name"], surface_feature=feature,
                            small_craters=craters and craters["count"])

    return {
        "coordinates": {"latitude": lat, "longitude": lon},
        "profile": {"id": profile.id, "label": profile.label, "maxSlopeDeg": profile.max_slope_deg},
        "region": region_at(lat, lon),
        "verdict": decide(evidence, profile),
        "terrain": terrain,
        "routeAvailable": local_grid(lat, lon, padding=55) is not None,
        "geology": unit,
        "surfaceFeature": feature,
        "smallCraters": craters,
        "landingEllipse": pack.in_landing_ellipse(lat, lon),
        "inJezeroMap": pack.in_map(lat, lon),
        "crater": hazard,
        "rover": pack.nearest_waypoint(lat, lon),
        "unavailable": UNAVAILABLE,
    }
