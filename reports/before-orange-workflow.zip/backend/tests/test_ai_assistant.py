import io
import json

from fastapi.testclient import TestClient

from app.main import app
from app import ai_assistant


def test_mission_advisor_uses_computed_evidence_and_cites_sources(monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")
    monkeypatch.setenv("MARS_GUIDE_MODEL", "test-model")
    monkeypatch.setattr(ai_assistant, "assessment", lambda latitude, longitude: {
        "level": "local", "routeAvailable": True, "factors": [{"key": "slope", "score": 90}],
    })
    monkeypatch.setattr(ai_assistant, "surface_routes", lambda latitude, longitude: {
        "routes": {"safest": {"metrics": {"risk_score": 4, "science_score": 0.6}}},
        "reason": None,
    })
    requests = []

    def fake_urlopen(request, timeout):
        requests.append(request)
        return io.BytesIO(json.dumps({
            "output": [{"type": "message", "content": [{"type": "output_text", "text": "التوصية [CTX]"}]}],
        }).encode())

    monkeypatch.setattr(ai_assistant, "urlopen", fake_urlopen)
    with TestClient(app) as client:
        response = client.post("/api/guide/mission", json={"candidates": [
            {"latitude": 18.45, "longitude": 77.45},
            {"latitude": 18.46, "longitude": 77.46},
        ]})

    assert response.status_code == 200
    assert response.json()["answer"] == "التوصية [CTX]"
    assert response.json()["sources"] == [{"id": "CTX", "url": ai_assistant.SOURCES["CTX"]}]
    assert len(requests) == 1
    assert requests[0].get_header("Authorization") == "Bearer test-key"
    payload = json.loads(requests[0].data)
    prompt = json.loads(payload["input"])
    assert len(prompt["candidates"]) == 2
    assert prompt["candidates"][0]["default_scout_route_metrics"]["safest"]["risk_score"] == 4
    assert "limited proxy" in payload["instructions"]


def test_mission_advisor_requires_two_candidates():
    with TestClient(app) as client:
        response = client.post("/api/guide/mission", json={"candidates": [
            {"latitude": 18.45, "longitude": 77.45},
        ]})

    assert response.status_code == 422


def test_mission_advisor_reports_missing_model_configuration(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("MARS_GUIDE_MODEL", raising=False)
    monkeypatch.setattr(ai_assistant, "assessment", lambda *_: (_ for _ in ()).throw(AssertionError()))
    with TestClient(app) as client:
        response = client.post("/api/guide/mission", json={"candidates": [
            {"latitude": 18.45, "longitude": 77.45},
            {"latitude": -5.44, "longitude": 137.7},
        ]})

    assert response.status_code == 503
    assert response.json()["detail"] == "AI model isn't configured. The local evidence guide is available."
