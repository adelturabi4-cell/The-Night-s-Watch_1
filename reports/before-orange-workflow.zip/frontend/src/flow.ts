/** The one path through the product: pick a place, read it, route to it, rehearse it. */
export const FLOW = [
  { key: 'explore', title: 'Explore', hint: 'Pick a point on Mars' },
  { key: 'location', title: 'Analyze', hint: 'Read the site evidence' },
  { key: 'planner', title: 'Plan route', hint: 'Compare three routes' },
  { key: 'simulator', title: 'Simulate', hint: 'Rehearse the traverse' },
] as const
export type FlowKey = typeof FLOW[number]['key']
