import { useEffect, useState } from 'react'
import { coordinatesLabel } from './mars'
import type { Coordinates } from './mars'
import { fetchSiteReport, MOBILITY_OPTIONS } from './siteIntel'
import type { Severity, SiteReport, VerdictStatus } from './siteIntel'
import './siteVerdict.css'

const STATUS_MARK: Record<VerdictStatus, string> = { go: '✓', caution: '!', no_go: '✕', unknown: '?' }
const SEVERITY_MARK: Record<Severity, string> = { block: '✕', warn: '!', ok: '✓', info: 'i' }
const SEVERITY_LABEL: Record<Severity, string> = { block: 'مانع', warn: 'تحذير', ok: 'سليم', info: 'معلومة' }
const number = (value: number | null, digits: number, unit: string) => value === null ? 'غير متاح' : `${value.toFixed(digits)} ${unit}`

interface Props {
  point: Coordinates
  defaultProfile: string
  onPlanRoute?: () => void
}

/** Answers "what is here, can I go there, and why" for the selected map point. */
export default function SiteVerdict({ point, defaultProfile, onPlanRoute }: Props) {
  const [profile, setProfile] = useState(defaultProfile)
  const [response, setResponse] = useState<{ key: string; data?: SiteReport; error?: string } | null>(null)
  const [attempt, setAttempt] = useState(0)
  const key = `${point.latitude},${point.longitude},${profile},${attempt}`
  const current = response?.key === key ? response : null
  const data = current?.data

  useEffect(() => {
    const controller = new AbortController()
    fetchSiteReport(point, profile, controller.signal)
      .then((result) => { if (!controller.signal.aborted) setResponse({ key, data: result }) })
      .catch((error) => { if (!controller.signal.aborted) setResponse({ key, error: error.message }) })
    return () => controller.abort()
  }, [point, profile, key])

  return (
    <section className="site-verdict" dir="rtl" lang="ar" aria-label="معلومات الموقع المحدد" data-status={data?.verdict.status ?? 'loading'}>
      <header className="site-verdict-head">
        <div>
          <span className="site-verdict-kicker">الموقع المحدد</span>
          <h3>{data ? data.region.displayName.replace(/^Near /, 'قرب ') : '…'}</h3>
          <p dir="ltr">{coordinatesLabel(point)}{data && ` · ${data.region.type}`}</p>
        </div>
        <label className="site-verdict-profile">وسيلة الحركة
          <select value={profile} onChange={(event) => setProfile(event.target.value)}>
            {MOBILITY_OPTIONS.map((option) => <option key={option.id} value={option.id}>{option.label}</option>)}
          </select>
        </label>
      </header>

      {!current && <p className="site-verdict-wait" role="status">جارٍ فحص بيانات النقطة…</p>}
      {current?.error && <p className="site-verdict-wait" role="alert">{current.error} <button onClick={() => setAttempt((value) => value + 1)}>إعادة المحاولة</button></p>}

      {data && <>
        <div className="site-verdict-banner" role="status">
          <span className="site-verdict-mark" aria-hidden="true">{STATUS_MARK[data.verdict.status]}</span>
          <div>
            <strong>{data.verdict.label}</strong>
            <span>{data.verdict.confidence === 'local' ? `حكم محلي · خلية ${data.terrain.resolutionM} م` : 'فحص إقليمي فقط · لا توجد تضاريس محلية'} · حد الميل {data.profile.maxSlopeDeg}°</span>
          </div>
        </div>

        <h4>لماذا؟</h4>
        <ul className="site-verdict-reasons">
          {data.verdict.reasons.map((reason) => (
            <li key={reason.code} data-severity={reason.severity}>
              <span className="site-verdict-chip" title={SEVERITY_LABEL[reason.severity]}><span aria-hidden="true">{SEVERITY_MARK[reason.severity]}</span><span className="sr-only">{SEVERITY_LABEL[reason.severity]}: </span></span>
              <span>{reason.text}{reason.source && <small dir="ltr"> {reason.source}</small>}</span>
            </li>
          ))}
        </ul>
        <p className="site-verdict-next">{data.verdict.nextStep}
          {data.routeAvailable && onPlanRoute && data.verdict.status !== 'no_go' && <button onClick={onPlanRoute}>احسب المسار إلى هنا</button>}
        </p>

        <dl className="site-verdict-facts">
          <div><dt>الارتفاع</dt><dd dir="ltr">{number(data.terrain.elevationM, 0, 'm')}</dd></div>
          <div><dt>الميل</dt><dd dir="ltr">{number(data.terrain.slopeDeg, 1, '°')}</dd></div>
          <div><dt>الخشونة</dt><dd dir="ltr">{number(data.terrain.roughnessM, 2, 'm RMS')}</dd></div>
          <div><dt>دقة البيانات</dt><dd dir="ltr">{data.terrain.resolutionM.toLocaleString('en')} m</dd></div>
        </dl>

        <div className="site-verdict-grid">
          <article>
            <h4>الجيولوجيا</h4>
            {data.geology ? <>
              <p className="site-verdict-unit"><i style={{ background: data.geology.color ?? 'transparent' }} aria-hidden="true" /><b dir="ltr">{data.geology.symbol}</b> <span dir="ltr">{data.geology.name}</span></p>
              <details><summary>الوصف والتفسير العلمي</summary>
                <p dir="ltr" lang="en">{data.geology.description}</p>
                {data.geology.interpretation && <p dir="ltr" lang="en"><b>Interpretation:</b> {data.geology.interpretation}</p>}
              </details>
              <small>خريطة USGS SIM 3464 · مقياس {data.geology.scale} · خريطة تفسيرية وليست جرد عوائق. <a href="https://doi.org/10.3133/sim3464" target="_blank" rel="noreferrer">المصدر ↗</a></small>
              {data.landingEllipse && <p className="site-verdict-tag">داخل قطع هبوط Perseverance</p>}
              {data.surfaceFeature && <p className="site-verdict-tag" dir="ltr">{data.surfaceFeature}</p>}
            </> : <p className="site-verdict-empty">خارج الخريطة الجيولوجية التفصيلية (Jezero / Nili Planum). لا توجد وحدة جيولوجية بمقياس 1:75,000 لهذه النقطة.</p>}
          </article>

          <article>
            <h4>أقرب موقع لعربة Perseverance</h4>
            {data.rover ? <>
              <p><b dir="ltr">Sol {data.rover.sol}</b> · يبعد <span dir="ltr">{data.rover.distanceM >= 1000 ? `${(data.rover.distanceM / 1000).toFixed(1)} km` : `${data.rover.distanceM.toFixed(0)} m`}</span></p>
              {data.rover.images[0]
                ? <p><a href={data.rover.images[0].url} target="_blank" rel="noreferrer">افتح بانوراما NASA ↗</a><br /><small>{data.rover.imageAtSelection ? 'التُقطت عند هذا الموقع المسجَّل.' : 'الصورة من موقع العربة المسجَّل، وليست من النقطة التي اخترتها.'}</small></p>
                : <p className="site-verdict-empty">لا توجد صورة سطحية لهذا الموقع.</p>}
              <small dir="ltr">{data.rover.credit}</small>
            </> : <p className="site-verdict-empty">لا توجد مواقع مسجَّلة للعربة قرب هذه النقطة، ولا صورة سطحية لها.</p>}
          </article>
        </div>

        <details className="site-verdict-missing">
          <summary>بيانات غير متاحة لهذه النقطة ({data.unavailable.length})</summary>
          <ul>{data.unavailable.map((item) => <li key={item.key}><b>{item.label}:</b> {item.why}</li>)}</ul>
        </details>
        <p className="site-verdict-limits">{data.verdict.limits} <span dir="ltr">{data.terrain.source}</span></p>
      </>}
    </section>
  )
}
