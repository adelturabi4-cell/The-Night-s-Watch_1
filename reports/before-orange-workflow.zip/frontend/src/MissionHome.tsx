import { lazy, Suspense, useEffect, useState } from 'react'
import Icon from './Icon'
import MapBoundary from './MapBoundary'
import PlanetMap from './PlanetMap'
import { coordinatesLabel, DEFAULT_LANDING_WEIGHTS, fetchMars, identifyRegion, LANDMARKS, scoreAssessment } from './mars'
import type { Assessment, Coordinates } from './mars'
import { siteTitle } from './science'
import type { Candidate } from './science'
import { isJezero, JEZERO_WEATHER, terrainStatus } from './siteNarration'
import SurfaceNavigation from './SurfaceNavigation'
import { useSurfaceNavigation } from './surfaceNavigationContext'
import LocationEvidence from './LocationEvidence'

const MarsGlobe = lazy(() => import('./MarsGlobe'))

function webglAvailable() {
  try {
    const context = document.createElement('canvas').getContext('webgl2')
    context?.getExtension('WEBGL_lose_context')?.loseContext()
    return Boolean(context)
  } catch { return false }
}

export default function MissionHome({ candidates, point, onSelect, onSave }: {
  candidates: Candidate[]
  point: Coordinates
  onSelect: (point: Coordinates, openReport?: boolean) => void
  onSave: (point: Coordinates, assessment: Assessment) => void
}) {
  const [response, setResponse] = useState<{ point: Coordinates; data?: Assessment; error?: string; attempt: number } | null>(null)
  const [attempt, setAttempt] = useState(0)
  const [globeSupported] = useState(webglAvailable)
  const [view, setView] = useState<'globe' | 'map'>(() => globeSupported ? 'globe' : 'map')
  const [grid, setGrid] = useState(true)
  const [focus, setFocus] = useState({ sequence: 1, distance: 4.2 })
  const [zoom, setZoom] = useState({ sequence: 0, direction: 0 })
  const [tileStatus, setTileStatus] = useState('')
  const navigation = useSurfaceNavigation()
  const current = response?.point === point && response.attempt === attempt ? response : null
  const assessment = current?.data
  const error = current?.error
  const score = assessment ? scoreAssessment(assessment.factors, DEFAULT_LANDING_WEIGHTS) : null
  const factor = (key: string) => assessment?.factors.find((item) => item.key === key)
  const elevation = factor('elevation')?.value
  const slope = factor('slope')?.value
  const safety = assessment ? terrainStatus(assessment, score) : 'unknown'
  const select = (next: Coordinates) => { onSelect(next, false); setFocus((value) => ({ sequence: value.sequence + 1, distance: 3.8 })) }

  useEffect(() => {
    const controller = new AbortController()
    fetchMars<Assessment>('', point, controller.signal)
      .then((data) => { if (!controller.signal.aborted) setResponse({ point, data, attempt }) })
      .catch((err) => { if (!controller.signal.aborted) setResponse({ point, error: err.message, attempt }) })
    return () => controller.abort()
  }, [point, attempt])

  const mapProps = { point, focus, zoom, layer: 'natural' as const, grid, showSlopes: false, hazard: null, paths: navigation.pathsFor(point), activeRoute: navigation.strategy, onSelect: select, onTileStatus: setTileStatus }
  const map = <PlanetMap {...mapProps} />
  return <section className="mission-content control-center">
    <div className="page-heading"><div><h1>Mission Control</h1><p className="page-description">Selected site, saved candidates and shortcuts into the workflow.</p></div><a className="button-link" href="#explore"><Icon name="globe" size={16} />Open explorer<Icon name="arrow" size={15} /></a></div>
    <div className="dashboard-layout">
      <div className="dashboard-primary">
        <section className="orbital-panel">
          <div className="panel-title"><div><Icon name="globe" size={17} /><h2>Planetary explorer</h2><span className="tag">MARS</span></div><div className="seg"><button aria-pressed={view === 'globe'} disabled={!globeSupported} onClick={() => setView('globe')}>3D globe</button><button aria-pressed={view === 'map'} onClick={() => setView('map')}>2D map</button></div></div>
          <div className="dashboard-globe mars-stage">
            <div className="orbital-topline"><span>VIKING ORBITAL MOSAIC<small>NASA / JPL-Caltech / USGS</small></span><span className="orbital-north">N ↑</span></div>
            {view === 'globe' ? <MapBoundary fallback={map}><Suspense fallback={<p className="mars-globe-fallback" role="status">Loading orbital imagery…</p>}><MarsGlobe {...mapProps} marked showHazard={false} showRelief /></Suspense></MapBoundary> : map}
            <div className="orbital-label"><span>SELECTED REGION</span><strong>{siteTitle(point)}</strong><small>{coordinatesLabel(point)}</small></div>
            <div className="mars-stage-controls"><button aria-label="Zoom in" onClick={() => setZoom((value) => ({ sequence: value.sequence + 1, direction: 1 }))}>+</button><button aria-label="Zoom out" onClick={() => setZoom((value) => ({ sequence: value.sequence + 1, direction: -1 }))}>−</button><button aria-label="Reset planetary view" onClick={() => setFocus((value) => ({ sequence: value.sequence + 1, distance: 4.2 }))}>↺</button></div>
            <div className="orbital-bottomline"><span>{view === 'globe' ? 'DRAG TO ROTATE' : 'DRAG TO PAN'} · CLICK TO SELECT</span><label><input type="checkbox" checked={grid} onChange={(event) => setGrid(event.target.checked)} />Coordinate grid</label></div>
          </div>
          <div className="orbital-regions"><span>QUICK LOCATE</span>{LANDMARKS.slice(0, 4).map((region) => <button key={region.name} aria-pressed={region.latitude === point.latitude && region.longitude === point.longitude} onClick={() => select(region)}>{region.name}</button>)}</div>
          {tileStatus && <p className="map-service-note" role="status">{tileStatus}</p>}
        </section>
        <section className="quick-tools"><div className="section-heading"><h2>Mission workspaces</h2><span>FROM ORBIT TO OPERATIONS</span></div><div className="quick-tool-grid">{[
          { href: 'planner', icon: 'route', title: 'Plan a traverse', detail: 'Compare three route strategies' },
          { href: 'landing', icon: 'landing', title: 'Evaluate a landing site', detail: 'Terrain, hazards & suitability' },
          { href: 'advisor', icon: 'advisor', title: 'Ask the mission advisor', detail: 'Reason from available evidence' },
        ].map((tool) => <a href={'#' + tool.href} key={tool.href}><span className="tool-icon"><Icon name={tool.icon} size={20} /></span><b>{tool.title}</b><small>{tool.detail}</small><Icon name="arrow" size={16} /></a>)}</div></section>
      </div>
      <aside className="dashboard-intelligence">
        <section className="intelligence-card overview-box"><div className="panel-title"><h2>Site overview</h2><Icon name="activity" size={16} /></div>
          <div className="overview-stats compact-overview">{[
            { label: 'Selected elevation', value: elevation == null ? '—' : elevation.toLocaleString('en', { maximumFractionDigits: 0 }), unit: elevation == null ? '' : 'm', detail: 'Orbital elevation model', icon: 'terrain' },
            { label: 'Surface slope', value: slope == null ? '—' : slope.toFixed(1), unit: slope == null ? '' : '°', detail: assessment?.level === 'local' ? 'Derived · local CTX grid' : 'Derived · regional MOLA', icon: 'activity' },
            { label: 'Terrain resolution', value: assessment ? String(assessment.resolutionM ?? (assessment.level === 'local' ? 20 : 3705)) : '—', unit: assessment ? 'm' : '', detail: assessment?.level === 'local' ? 'Jezero study area' : 'MOLA regional grid', icon: 'data' },
            { label: 'Saved candidates', value: String(candidates.length).padStart(2, '0'), unit: '', detail: 'Available for site comparison', icon: 'location' },
          ].map((stat) => <article className="overview-stat" key={stat.label}><div><span>{stat.label}</span><Icon name={stat.icon} size={14} /></div><strong>{stat.value}<small>{stat.unit}</small></strong><p>{stat.detail}</p></article>)}</div>
        </section>
        <SurfaceNavigation point={point} onFocus={() => setFocus((value) => ({ sequence: value.sequence + 1, distance: 1.003 }))} />
        <LocationEvidence assessment={assessment} />
        <section className="intelligence-card selected-site"><div className="panel-title"><h2>Selected landing site</h2><Icon name="location" size={16} /></div><div className="site-card-body"><p className="page-kicker">{identifyRegion(point)?.type ?? 'SURFACE COORDINATES'}</p><h3>{siteTitle(point)}</h3><p className="site-coordinate">{coordinatesLabel(point)}</p>
          <div className="site-image-strip"><img src="/mars/jezero-relief.png" alt="Bundled Jezero CTX hillshade study area" /><span>JEZERO CTX STUDY AREA<small>Reference coverage · 20 m cells</small></span></div>
          {error ? <div className="inline-error" role="alert"><p>{error}</p><button onClick={() => setAttempt((value) => value + 1)}>Retry assessment</button></div> : <><dl className="site-brief"><div><dt>Terrain classification</dt><dd>{identifyRegion(point)?.type ?? 'Unclassified'}</dd></div><div><dt>Assessment coverage</dt><dd>{assessment ? assessment.level === 'local' ? 'Local CTX terrain' : 'Regional MOLA' : 'Loading…'}</dd></div><div><dt>Hazard assessment</dt><dd>{!assessment ? 'Loading…' : safety === 'unknown' ? 'Undetermined' : safety === 'elevated' ? 'Elevated modeled risk' : 'Lower modeled risk'}</dd></div></dl><a className="button-link primary-link" href="#location">View location analysis<Icon name="arrow" size={16} /></a></>}
        </div></section>
        <section className="intelligence-card"><div className="panel-title"><h2>Terrain screening</h2><span className="tag">DERIVED</span></div><div className="screening-body"><div className="score-ring"><svg viewBox="0 0 100 100" aria-hidden="true"><circle cx="50" cy="50" r="42" /><circle cx="50" cy="50" r="42" pathLength="100" strokeDasharray={(score ?? 0) + ' 100'} /></svg><strong>{score ?? '—'}<small>/ 100</small></strong></div><div><b>{assessment?.level === 'local' ? 'Local terrain score' : 'Regional terrain score'}</b><p>Weighted screening of available terrain factors.</p><button className="text-button" disabled={!assessment} onClick={() => { if (assessment) onSave(point, assessment) }}>Save candidate <Icon name="arrow" size={14} /></button></div></div><p className="card-footnote">Preliminary model. Vehicle and obstacle validation required.</p></section>
        <section className="intelligence-card conditions-card"><div className="panel-title"><h2>Environmental context</h2><Icon name="sun" size={16} /></div><div className="conditions-body"><div><span>Current temperature</span><strong>Unavailable</strong></div><div><span>{isJezero(point) ? 'Historical pressure' : 'Local pressure'}</span><strong>{isJezero(point) ? JEZERO_WEATHER.pressure : 'Unavailable'}</strong></div><p>{isJezero(point) ? 'MEDA · first 250 sols. Historical rover measurements.' : 'Select Jezero for the available MEDA historical reference.'}</p><a href="#survival">Review environmental evidence <Icon name="arrow" size={14} /></a></div></section>
      </aside>
    </div>
    <div className="dashboard-bottom">
      <section className="intelligence-card recent-analyses"><div className="panel-title"><h2>Recent analyses</h2><a href="#reports">View all ↗</a></div>{candidates.length ? <div className="analysis-list">{candidates.slice(0, 3).map((candidate) => <button key={coordinatesLabel(candidate.point)} onClick={() => onSelect(candidate.point)}><span className="analysis-icon"><Icon name="location" size={18} /></span><span><b>{siteTitle(candidate.point)}</b><small>{coordinatesLabel(candidate.point)}</small></span><span className="analysis-type">{candidate.assessment.level === 'local' ? 'LOCAL TERRAIN' : 'REGIONAL SCREEN'}</span><Icon name="arrow" size={15} /></button>)}</div> : <div className="empty-inline"><p>Save a candidate from a site analysis to build your mission shortlist.</p><a href="#location">Analyze site ↗</a></div>}</section>
      <section className="intelligence-card"><div className="panel-title"><h2>Mission activity</h2><span className="micro-label">BROWSER LOCAL</span></div><ol className="activity-timeline"><li><i /><div><b>Current exploration focus</b><p>{siteTitle(point)} · {coordinatesLabel(point)}</p></div></li>{candidates.slice(0, 2).map((candidate) => <li key={candidate.savedAt + coordinatesLabel(candidate.point)}><i /><div><b>Site analysis saved</b><p>{siteTitle(candidate.point)}</p><time dateTime={candidate.savedAt}>{new Date(candidate.savedAt).toLocaleString()}</time></div></li>)}{!candidates.length && <li><i /><div><b>Ready for your first analysis</b><p>Saved candidates and analyses appear here.</p></div></li>}</ol></section>
    </div>
    <section className="research-reading"><p className="page-kicker">FROM THE SCIENCE ARCHIVE</p><a href="https://science.nasa.gov/photojournal/mars-global-localization-pinpoints-perseverances-location/" target="_blank" rel="noreferrer">Perseverance localization from orbital maps<Icon name="external" size={14} /></a><a href="https://science.nasa.gov/blog/linking-local-lithologies-to-a-larger-landscape/" target="_blank" rel="noreferrer">Rocks on Jezero’s rim<Icon name="external" size={14} /></a></section>
  </section>
}
